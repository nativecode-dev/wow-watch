-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AlternativeTitles`
--

DROP TABLE IF EXISTS `AlternativeTitles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AlternativeTitles` (
  `Id` int(11) DEFAULT NULL,
  `MovieId` int(11) DEFAULT NULL,
  `Title` text,
  `CleanTitle` text,
  `SourceType` int(11) DEFAULT NULL,
  `SourceId` int(11) DEFAULT NULL,
  `Votes` int(11) DEFAULT NULL,
  `VoteCount` int(11) DEFAULT NULL,
  `Language` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AlternativeTitles`
--

LOCK TABLES `AlternativeTitles` WRITE;
/*!40000 ALTER TABLE `AlternativeTitles` DISABLE KEYS */;
/*!40000 ALTER TABLE `AlternativeTitles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Blacklist`
--

DROP TABLE IF EXISTS `Blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Blacklist` (
  `Id` int(11) DEFAULT NULL,
  `SourceTitle` text,
  `Quality` text,
  `Date` datetime DEFAULT NULL,
  `PublishedDate` datetime DEFAULT NULL,
  `Size` int(11) DEFAULT NULL,
  `Protocol` int(11) DEFAULT NULL,
  `Indexer` text,
  `Message` text,
  `TorrentInfoHash` text,
  `MovieId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Blacklist`
--

LOCK TABLES `Blacklist` WRITE;
/*!40000 ALTER TABLE `Blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `Blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Commands`
--

DROP TABLE IF EXISTS `Commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Commands` (
  `Id` int(11) DEFAULT NULL,
  `Name` text,
  `Body` text,
  `Priority` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `QueuedAt` datetime DEFAULT NULL,
  `StartedAt` datetime DEFAULT NULL,
  `EndedAt` datetime DEFAULT NULL,
  `Duration` text,
  `Exception` text,
  `Trigger` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Commands`
--

LOCK TABLES `Commands` WRITE;
/*!40000 ALTER TABLE `Commands` DISABLE KEYS */;
INSERT INTO `Commands` VALUES (1,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:46:05.141705Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0690520','',2),(2,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:47:35.39731Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0470550','',2),(3,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:48:35.627274Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0276970','',2),(4,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T18:46:05.422471Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0247660','',2),(5,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:50:05.752123Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0974160','',2),(6,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:51:36.028161Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0349240','',2),(7,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:53:06.120243Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0553890','',2),(8,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:54:36.488468Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0361750','',2),(9,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T18:51:05.837257Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0907590','',2),(10,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:56:06.675911Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.5531950','',2),(11,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:57:07.617082Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1700610','',2),(12,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:58:37.707198Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0443110','',2),(13,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T18:59:38.191782Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.2477920','',2),(14,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T18:56:06.875742Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0354180','',2),(15,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:01:09.170613Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.2217470','',2),(16,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:02:39.455499Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1374360','',2),(17,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:03:41.396059Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0520450','',2),(18,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:01:09.015245Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0454690','',2),(19,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:05:11.52511Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0478760','',2),(20,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:06:41.709361Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0301160','',2),(21,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:08:11.814574Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0472580','',2),(22,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:09:12.200626Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0459140','',2),(23,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:06:11.647504Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.3611200','',2),(24,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:10:42.298266Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0680530','',2),(25,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:11:42.59568Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0564040','',2),(26,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:13:12.667387Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0474190','',2),(27,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:14:42.755517Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0709340','',2),(28,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:11:12.792225Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0440420','',2),(29,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:16:12.852382Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0734240','',2),(30,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:17:13.110813Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0390130','',2),(31,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:18:43.284066Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0681160','',2),(32,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:20:13.381253Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.2200420','',2),(33,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:16:42.929664Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0285030','',2),(34,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:21:43.961072Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0453000','',2),(35,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:23:14.023013Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0740760','',2),(36,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:24:44.506411Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0281670','',2),(37,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:21:43.903866Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0744460','',2),(38,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:26:14.708338Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0420410','',2),(39,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:27:14.831602Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1166060','',2),(40,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:28:15.095474Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.2829500','',2),(41,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:29:45.458092Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0852410','',2),(42,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:26:44.828571Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.3335500','',2),(43,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:31:15.387202Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0525340','',2),(44,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:32:15.845008Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0393550','',2),(45,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:33:45.831702Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0522690','',2),(46,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:35:15.976138Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0215110','',2),(47,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:31:45.926431Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0230370','',2),(48,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:36:46.06753Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0262250','',2),(49,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:37:46.706478Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0472500','',2),(50,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:39:16.769422Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0306810','',2),(51,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:40:16.909316Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0426690','',2),(52,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:37:16.380988Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1913950','',2),(53,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:41:47.03515Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0742380','',2),(54,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:42:47.296478Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0421850','',2),(55,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:43:47.523255Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.2631260','',2),(56,'PreDBSync','{\n  \"sendUpdatesToClient\": true,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"PreDBSync\",\n  \"lastExecutionTime\": \"2019-03-04T18:46:05.338213Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0831280','',2),(57,'RssSync','{\n  \"sendUpdatesToClient\": true,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"RssSync\",\n  \"lastExecutionTime\": \"2019-03-04T18:46:05.868619Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1457810','',2),(58,'NetImportSync','{\n  \"listId\": 0,\n  \"sendUpdatesToClient\": true,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"NetImportSync\",\n  \"lastExecutionTime\": \"2019-03-04T18:46:05.936514Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1030600','',2),(59,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:45:17.951474Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0465560','',2),(60,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:42:17.278107Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0505890','',2),(61,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:46:48.069245Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0815120','',2),(62,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:47:48.327143Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0290370','',2),(63,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:48:48.558355Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0565680','',2),(64,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:50:18.73939Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0386540','',2),(65,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:47:18.173572Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0509460','',2),(66,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:51:48.795435Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0589850','',2),(67,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:52:48.95329Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0332840','',2),(68,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:54:59.835284Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0732490','',2),(69,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:52:18.913185Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0747650','',2),(70,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:56:30.070856Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0513990','',2),(71,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:58:00.382881Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0382960','',2),(72,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T19:59:30.454742Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0478600','',2),(73,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:01:00.726107Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.2131490','',2),(74,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T19:57:30.20989Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0536370','',2),(75,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:02:30.97301Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0816980','',2),(76,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:04:01.015571Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0897530','',2),(77,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:05:31.108211Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0222470','',2),(78,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:02:30.874862Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0792560','',2),(79,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:07:01.119803Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0463520','',2),(80,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:08:01.260308Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0816810','',2),(81,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:09:01.484564Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0570250','',2),(82,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:10:31.57999Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0588560','',2),(83,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:07:31.237416Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0321410','',2),(84,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:12:01.642039Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1172640','',2),(85,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:13:01.862341Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0512120','',2),(86,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:14:31.99994Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1319720','',2),(87,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:16:02.62488Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1462740','',2),(88,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:12:31.729183Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0636940','',2),(89,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:17:32.902102Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0637960','',2),(90,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:19:02.957544Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0876370','',2),(91,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:20:03.278406Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0222460','',2),(92,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:21:33.383904Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0836050','',2),(93,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:17:33.026293Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0424380','',2),(94,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:22:33.663898Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0569090','',2),(95,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:23:33.966736Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.1398950','',2),(96,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:25:04.178994Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0376750','',2),(97,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:22:33.76646Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0418760','',2),(98,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:26:34.253506Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0484820','',2),(99,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:28:04.501462Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0990740','',2),(100,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:29:34.613247Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0389820','',2),(101,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:31:04.751102Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0603220','',2),(102,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:27:34.376974Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0501630','',2),(103,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:32:35.017233Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0321160','',2),(104,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:34:05.344131Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0655210','',2),(105,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:35:35.242757Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0589040','',2),(106,'MessagingCleanup','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"MessagingCleanup\",\n  \"lastExecutionTime\": \"2019-03-04T20:32:34.933838Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0633020','',2),(107,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:37:05.351314Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0420760','',2),(108,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:38:05.536808Z\",\n  \"trigger\": \"scheduled\"\n}',-1,2,'2019-03-04 00:00:00','2019-03-04 00:00:00','2019-03-04 00:00:00','00:00:00.0589290','',2),(109,'CheckForFinishedDownload','{\n  \"sendUpdatesToClient\": false,\n  \"updateScheduledTask\": true,\n  \"completionMessage\": \"Completed\",\n  \"name\": \"CheckForFinishedDownload\",\n  \"lastExecutionTime\": \"2019-03-04T20:39:35.780225Z\",\n  \"trigger\": \"scheduled\"\n}',-1,0,'2019-03-04 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','','',2);
/*!40000 ALTER TABLE `Commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Config`
--

DROP TABLE IF EXISTS `Config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Config` (
  `Id` int(11) DEFAULT NULL,
  `Key` text,
  `Value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Config`
--

LOCK TABLES `Config` WRITE;
/*!40000 ALTER TABLE `Config` DISABLE KEYS */;
INSERT INTO `Config` VALUES (1,'enablecompleteddownloadhandling','True');
/*!40000 ALTER TABLE `Config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CustomFormats`
--

DROP TABLE IF EXISTS `CustomFormats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CustomFormats` (
  `Id` int(11) DEFAULT NULL,
  `Name` text,
  `FormatTags` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CustomFormats`
--

LOCK TABLES `CustomFormats` WRITE;
/*!40000 ALTER TABLE `CustomFormats` DISABLE KEYS */;
/*!40000 ALTER TABLE `CustomFormats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DelayProfiles`
--

DROP TABLE IF EXISTS `DelayProfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DelayProfiles` (
  `Id` int(11) DEFAULT NULL,
  `EnableUsenet` int(11) DEFAULT NULL,
  `EnableTorrent` int(11) DEFAULT NULL,
  `PreferredProtocol` int(11) DEFAULT NULL,
  `UsenetDelay` int(11) DEFAULT NULL,
  `TorrentDelay` int(11) DEFAULT NULL,
  `Order` int(11) DEFAULT NULL,
  `Tags` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DelayProfiles`
--

LOCK TABLES `DelayProfiles` WRITE;
/*!40000 ALTER TABLE `DelayProfiles` DISABLE KEYS */;
INSERT INTO `DelayProfiles` VALUES (1,1,1,1,0,0,2147483647,'[]');
/*!40000 ALTER TABLE `DelayProfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DownloadClients`
--

DROP TABLE IF EXISTS `DownloadClients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DownloadClients` (
  `Id` int(11) DEFAULT NULL,
  `Enable` int(11) DEFAULT NULL,
  `Name` text,
  `Implementation` text,
  `Settings` text,
  `ConfigContract` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DownloadClients`
--

LOCK TABLES `DownloadClients` WRITE;
/*!40000 ALTER TABLE `DownloadClients` DISABLE KEYS */;
/*!40000 ALTER TABLE `DownloadClients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExtraFiles`
--

DROP TABLE IF EXISTS `ExtraFiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExtraFiles` (
  `Id` int(11) DEFAULT NULL,
  `MovieId` int(11) DEFAULT NULL,
  `MovieFileId` int(11) DEFAULT NULL,
  `RelativePath` text,
  `Extension` text,
  `Added` datetime DEFAULT NULL,
  `LastUpdated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExtraFiles`
--

LOCK TABLES `ExtraFiles` WRITE;
/*!40000 ALTER TABLE `ExtraFiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExtraFiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `History`
--

DROP TABLE IF EXISTS `History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `History` (
  `Id` int(11) DEFAULT NULL,
  `SourceTitle` text,
  `Date` datetime DEFAULT NULL,
  `Quality` text,
  `Data` text,
  `EventType` int(11) DEFAULT NULL,
  `DownloadId` text,
  `MovieId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `History`
--

LOCK TABLES `History` WRITE;
/*!40000 ALTER TABLE `History` DISABLE KEYS */;
/*!40000 ALTER TABLE `History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ImportExclusions`
--

DROP TABLE IF EXISTS `ImportExclusions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ImportExclusions` (
  `Id` int(11) DEFAULT NULL,
  `TmdbId` int(11) DEFAULT NULL,
  `MovieTitle` text,
  `MovieYear` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ImportExclusions`
--

LOCK TABLES `ImportExclusions` WRITE;
/*!40000 ALTER TABLE `ImportExclusions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ImportExclusions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IndexerStatus`
--

DROP TABLE IF EXISTS `IndexerStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IndexerStatus` (
  `Id` int(11) DEFAULT NULL,
  `IndexerId` int(11) DEFAULT NULL,
  `InitialFailure` datetime DEFAULT NULL,
  `MostRecentFailure` datetime DEFAULT NULL,
  `EscalationLevel` int(11) DEFAULT NULL,
  `DisabledTill` datetime DEFAULT NULL,
  `LastRssSyncReleaseInfo` text,
  `Cookies` text,
  `CookiesExpirationDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IndexerStatus`
--

LOCK TABLES `IndexerStatus` WRITE;
/*!40000 ALTER TABLE `IndexerStatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `IndexerStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Indexers`
--

DROP TABLE IF EXISTS `Indexers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Indexers` (
  `Id` int(11) DEFAULT NULL,
  `Name` text,
  `Implementation` text,
  `Settings` text,
  `ConfigContract` text,
  `EnableRss` int(11) DEFAULT NULL,
  `EnableSearch` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Indexers`
--

LOCK TABLES `Indexers` WRITE;
/*!40000 ALTER TABLE `Indexers` DISABLE KEYS */;
/*!40000 ALTER TABLE `Indexers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Metadata`
--

DROP TABLE IF EXISTS `Metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Metadata` (
  `Id` int(11) DEFAULT NULL,
  `Enable` int(11) DEFAULT NULL,
  `Name` text,
  `Implementation` text,
  `Settings` text,
  `ConfigContract` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Metadata`
--

LOCK TABLES `Metadata` WRITE;
/*!40000 ALTER TABLE `Metadata` DISABLE KEYS */;
INSERT INTO `Metadata` VALUES (1,0,'WDTV','WdtvMetadata','{\n  \"movieMetadata\": true,\n  \"movieImages\": true,\n  \"isValid\": true\n}','WdtvMetadataSettings'),(2,0,'Roksbox','RoksboxMetadata','{\n  \"movieMetadata\": true,\n  \"movieImages\": true,\n  \"isValid\": true\n}','RoksboxMetadataSettings'),(3,0,'Emby (Legacy)','MediaBrowserMetadata','{\n  \"movieMetadata\": true,\n  \"isValid\": true\n}','MediaBrowserMetadataSettings'),(4,0,'Kodi (XBMC) / Emby','XbmcMetadata','{\n  \"movieMetadata\": true,\n  \"movieImages\": true,\n  \"useMovieNfo\": false,\n  \"isValid\": true\n}','XbmcMetadataSettings');
/*!40000 ALTER TABLE `Metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MetadataFiles`
--

DROP TABLE IF EXISTS `MetadataFiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MetadataFiles` (
  `Id` int(11) DEFAULT NULL,
  `MovieId` int(11) DEFAULT NULL,
  `Consumer` text,
  `Type` int(11) DEFAULT NULL,
  `RelativePath` text,
  `LastUpdated` datetime DEFAULT NULL,
  `MovieFileId` int(11) DEFAULT NULL,
  `Hash` text,
  `Added` datetime DEFAULT NULL,
  `Extension` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MetadataFiles`
--

LOCK TABLES `MetadataFiles` WRITE;
/*!40000 ALTER TABLE `MetadataFiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `MetadataFiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovieFiles`
--

DROP TABLE IF EXISTS `MovieFiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovieFiles` (
  `Id` int(11) DEFAULT NULL,
  `MovieId` int(11) DEFAULT NULL,
  `Path` text,
  `Quality` text,
  `Size` int(11) DEFAULT NULL,
  `DateAdded` datetime DEFAULT NULL,
  `SceneName` text,
  `MediaInfo` text,
  `ReleaseGroup` text,
  `RelativePath` text,
  `Edition` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovieFiles`
--

LOCK TABLES `MovieFiles` WRITE;
/*!40000 ALTER TABLE `MovieFiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `MovieFiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Movies`
--

DROP TABLE IF EXISTS `Movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Movies` (
  `Id` int(11) DEFAULT NULL,
  `ImdbId` text,
  `Title` text,
  `TitleSlug` text,
  `SortTitle` text,
  `CleanTitle` text,
  `Status` int(11) DEFAULT NULL,
  `Overview` text,
  `Images` text,
  `Path` text,
  `Monitored` int(11) DEFAULT NULL,
  `ProfileId` int(11) DEFAULT NULL,
  `LastInfoSync` datetime DEFAULT NULL,
  `LastDiskSync` datetime DEFAULT NULL,
  `Runtime` int(11) DEFAULT NULL,
  `InCinemas` datetime DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Added` datetime DEFAULT NULL,
  `Actors` text,
  `Ratings` text,
  `Genres` text,
  `Tags` text,
  `Certification` text,
  `AddOptions` text,
  `MovieFileId` int(11) DEFAULT NULL,
  `TmdbId` int(11) DEFAULT NULL,
  `Website` text,
  `PhysicalRelease` datetime DEFAULT NULL,
  `YouTubeTrailerId` text,
  `Studio` text,
  `MinimumAvailability` int(11) DEFAULT NULL,
  `HasPreDBEntry` int(11) DEFAULT NULL,
  `PathState` int(11) DEFAULT NULL,
  `PhysicalReleaseNote` text,
  `SecondaryYear` int(11) DEFAULT NULL,
  `SecondaryYearSourceId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Movies`
--

LOCK TABLES `Movies` WRITE;
/*!40000 ALTER TABLE `Movies` DISABLE KEYS */;
/*!40000 ALTER TABLE `Movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NamingConfig`
--

DROP TABLE IF EXISTS `NamingConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NamingConfig` (
  `Id` int(11) DEFAULT NULL,
  `MultiEpisodeStyle` int(11) DEFAULT NULL,
  `RenameEpisodes` int(11) DEFAULT NULL,
  `ReplaceIllegalCharacters` int(11) DEFAULT NULL,
  `StandardMovieFormat` text,
  `MovieFolderFormat` text,
  `ColonReplacementFormat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NamingConfig`
--

LOCK TABLES `NamingConfig` WRITE;
/*!40000 ALTER TABLE `NamingConfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `NamingConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NetImport`
--

DROP TABLE IF EXISTS `NetImport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NetImport` (
  `Id` int(11) DEFAULT NULL,
  `Enabled` int(11) DEFAULT NULL,
  `Name` text,
  `Implementation` text,
  `ConfigContract` text,
  `Settings` text,
  `EnableAuto` int(11) DEFAULT NULL,
  `RootFolderPath` text,
  `ShouldMonitor` int(11) DEFAULT NULL,
  `ProfileId` int(11) DEFAULT NULL,
  `MinimumAvailability` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NetImport`
--

LOCK TABLES `NetImport` WRITE;
/*!40000 ALTER TABLE `NetImport` DISABLE KEYS */;
/*!40000 ALTER TABLE `NetImport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notifications`
--

DROP TABLE IF EXISTS `Notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notifications` (
  `Id` int(11) DEFAULT NULL,
  `Name` text,
  `OnGrab` int(11) DEFAULT NULL,
  `OnDownload` int(11) DEFAULT NULL,
  `Settings` text,
  `Implementation` text,
  `ConfigContract` text,
  `OnUpgrade` int(11) DEFAULT NULL,
  `Tags` text,
  `OnRename` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notifications`
--

LOCK TABLES `Notifications` WRITE;
/*!40000 ALTER TABLE `Notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PendingReleases`
--

DROP TABLE IF EXISTS `PendingReleases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PendingReleases` (
  `Id` int(11) DEFAULT NULL,
  `Title` text,
  `Added` datetime DEFAULT NULL,
  `Release` text,
  `MovieId` int(11) DEFAULT NULL,
  `ParsedMovieInfo` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PendingReleases`
--

LOCK TABLES `PendingReleases` WRITE;
/*!40000 ALTER TABLE `PendingReleases` DISABLE KEYS */;
/*!40000 ALTER TABLE `PendingReleases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Profiles`
--

DROP TABLE IF EXISTS `Profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Profiles` (
  `Id` int(11) DEFAULT NULL,
  `Name` text,
  `Cutoff` int(11) DEFAULT NULL,
  `Items` text,
  `Language` int(11) DEFAULT NULL,
  `PreferredTags` text,
  `FormatItems` text,
  `FormatCutoff` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Profiles`
--

LOCK TABLES `Profiles` WRITE;
/*!40000 ALTER TABLE `Profiles` DISABLE KEYS */;
INSERT INTO `Profiles` VALUES (1,'Any',20,'[\n  {\n    \"quality\": 0,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 24,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 25,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 26,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 27,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 29,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 28,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 1,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 2,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 23,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 8,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 20,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 21,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 4,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 5,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 6,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 9,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 3,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 7,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 30,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 16,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 18,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 19,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 31,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 22,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 10,\n    \"allowed\": false\n  }\n]',1,'','[\n  {\n    \"format\": 0,\n    \"allowed\": true\n  }\n]',0),(2,'SD',20,'[\n  {\n    \"quality\": 0,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 24,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 25,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 26,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 27,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 29,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 28,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 1,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 2,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 23,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 8,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 20,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 21,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 4,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 5,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 6,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 9,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 3,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 7,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 30,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 16,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 18,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 19,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 31,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 22,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 10,\n    \"allowed\": false\n  }\n]',1,'','[\n  {\n    \"format\": 0,\n    \"allowed\": true\n  }\n]',0),(3,'HD-720p',6,'[\n  {\n    \"quality\": 0,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 24,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 25,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 26,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 27,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 29,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 28,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 1,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 2,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 23,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 8,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 20,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 21,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 4,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 5,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 6,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 9,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 3,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 7,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 30,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 16,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 18,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 19,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 31,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 22,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 10,\n    \"allowed\": false\n  }\n]',1,'','[\n  {\n    \"format\": 0,\n    \"allowed\": true\n  }\n]',0),(4,'HD-1080p',7,'[\n  {\n    \"quality\": 0,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 24,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 25,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 26,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 27,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 29,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 28,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 1,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 2,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 23,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 8,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 20,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 21,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 4,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 5,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 6,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 9,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 3,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 7,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 30,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 16,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 18,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 19,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 31,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 22,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 10,\n    \"allowed\": false\n  }\n]',1,'','[\n  {\n    \"format\": 0,\n    \"allowed\": true\n  }\n]',0),(5,'Ultra-HD',31,'[\n  {\n    \"quality\": 0,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 24,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 25,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 26,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 27,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 29,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 28,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 1,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 2,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 23,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 8,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 20,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 21,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 4,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 5,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 6,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 9,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 3,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 7,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 30,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 16,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 18,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 19,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 31,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 22,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 10,\n    \"allowed\": false\n  }\n]',1,'','[\n  {\n    \"format\": 0,\n    \"allowed\": true\n  }\n]',0),(6,'HD - 720p/1080p',6,'[\n  {\n    \"quality\": 0,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 24,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 25,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 26,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 27,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 29,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 28,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 1,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 2,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 23,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 8,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 20,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 21,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 4,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 5,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 6,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 9,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 3,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 7,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 30,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 16,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 18,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 19,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 31,\n    \"allowed\": true\n  },\n  {\n    \"quality\": 22,\n    \"allowed\": false\n  },\n  {\n    \"quality\": 10,\n    \"allowed\": false\n  }\n]',1,'','[\n  {\n    \"format\": 0,\n    \"allowed\": true\n  }\n]',0);
/*!40000 ALTER TABLE `Profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QualityDefinitions`
--

DROP TABLE IF EXISTS `QualityDefinitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QualityDefinitions` (
  `Id` int(11) DEFAULT NULL,
  `Quality` int(11) DEFAULT NULL,
  `Title` text,
  `MinSize` text,
  `MaxSize` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QualityDefinitions`
--

LOCK TABLES `QualityDefinitions` WRITE;
/*!40000 ALTER TABLE `QualityDefinitions` DISABLE KEYS */;
INSERT INTO `QualityDefinitions` VALUES (1,0,'Unknown','0','100'),(2,24,'WORKPRINT','0','100'),(3,25,'CAM','0','100'),(4,26,'TELESYNC','0','100'),(5,27,'TELECINE','0','100'),(6,29,'REGIONAL','0','100'),(7,28,'DVDSCR','0','100'),(8,1,'SDTV','0','100'),(9,2,'DVD','0','100'),(10,23,'DVD-R','0','100'),(11,8,'WEBDL-480p','0','100'),(12,20,'Bluray-480p','0','100'),(13,21,'Bluray-576p','0','100'),(14,4,'HDTV-720p','0','100'),(15,5,'WEBDL-720p','0','100'),(16,6,'Bluray-720p','0','100'),(17,9,'HDTV-1080p','0','100'),(18,3,'WEBDL-1080p','0','100'),(19,7,'Bluray-1080p','0',''),(20,30,'Remux-1080p','0',''),(21,16,'HDTV-2160p','0',''),(22,18,'WEBDL-2160p','0',''),(23,19,'Bluray-2160p','0',''),(24,31,'Remux-2160p','0',''),(25,22,'BR-DISK','0',''),(26,10,'Raw-HD','0','');
/*!40000 ALTER TABLE `QualityDefinitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RemotePathMappings`
--

DROP TABLE IF EXISTS `RemotePathMappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RemotePathMappings` (
  `Id` int(11) DEFAULT NULL,
  `Host` text,
  `RemotePath` text,
  `LocalPath` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RemotePathMappings`
--

LOCK TABLES `RemotePathMappings` WRITE;
/*!40000 ALTER TABLE `RemotePathMappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `RemotePathMappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Restrictions`
--

DROP TABLE IF EXISTS `Restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Restrictions` (
  `Id` int(11) DEFAULT NULL,
  `Required` text,
  `Preferred` text,
  `Ignored` text,
  `Tags` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Restrictions`
--

LOCK TABLES `Restrictions` WRITE;
/*!40000 ALTER TABLE `Restrictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RootFolders`
--

DROP TABLE IF EXISTS `RootFolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RootFolders` (
  `Id` int(11) DEFAULT NULL,
  `Path` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RootFolders`
--

LOCK TABLES `RootFolders` WRITE;
/*!40000 ALTER TABLE `RootFolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `RootFolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScheduledTasks`
--

DROP TABLE IF EXISTS `ScheduledTasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScheduledTasks` (
  `Id` int(11) DEFAULT NULL,
  `TypeName` text,
  `Interval` text,
  `LastExecution` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScheduledTasks`
--

LOCK TABLES `ScheduledTasks` WRITE;
/*!40000 ALTER TABLE `ScheduledTasks` DISABLE KEYS */;
INSERT INTO `ScheduledTasks` VALUES (1,'NzbDrone.Core.Download.CheckForFinishedDownloadCommand','1','2019-03-04 00:00:00'),(2,'NzbDrone.Core.MetadataSource.PreDB.PreDBSyncCommand','60','2019-03-04 00:00:00'),(3,'NzbDrone.Core.Messaging.Commands.MessagingCleanupCommand','5','2019-03-04 00:00:00'),(4,'NzbDrone.Core.Update.Commands.ApplicationUpdateCommand','360','2019-03-04 00:00:00'),(5,'NzbDrone.Core.HealthCheck.CheckHealthCommand','360','2019-03-04 00:00:00'),(6,'NzbDrone.Core.Movies.Commands.RefreshMovieCommand','1440','2019-03-04 00:00:00'),(7,'NzbDrone.Core.Housekeeping.HousekeepingCommand','1440','2019-03-04 00:00:00'),(8,'NzbDrone.Core.Backup.BackupCommand','10080','2019-03-04 00:00:00'),(9,'NzbDrone.Core.Indexers.RssSyncCommand','60','2019-03-04 00:00:00'),(10,'NzbDrone.Core.NetImport.NetImportSyncCommand','60','2019-03-04 00:00:00'),(11,'NzbDrone.Core.MediaFiles.Commands.DownloadedMoviesScanCommand','0','2019-03-04 00:00:00');
/*!40000 ALTER TABLE `ScheduledTasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubtitleFiles`
--

DROP TABLE IF EXISTS `SubtitleFiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SubtitleFiles` (
  `Id` int(11) DEFAULT NULL,
  `MovieId` int(11) DEFAULT NULL,
  `MovieFileId` int(11) DEFAULT NULL,
  `RelativePath` text,
  `Extension` text,
  `Added` datetime DEFAULT NULL,
  `LastUpdated` datetime DEFAULT NULL,
  `Language` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubtitleFiles`
--

LOCK TABLES `SubtitleFiles` WRITE;
/*!40000 ALTER TABLE `SubtitleFiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `SubtitleFiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tags`
--

DROP TABLE IF EXISTS `Tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tags` (
  `Id` int(11) DEFAULT NULL,
  `Label` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tags`
--

LOCK TABLES `Tags` WRITE;
/*!40000 ALTER TABLE `Tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `Id` int(11) DEFAULT NULL,
  `Identifier` text,
  `Username` text,
  `Password` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VersionInfo`
--

DROP TABLE IF EXISTS `VersionInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VersionInfo` (
  `Version` int(11) DEFAULT NULL,
  `AppliedOn` datetime DEFAULT NULL,
  `Description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VersionInfo`
--

LOCK TABLES `VersionInfo` WRITE;
/*!40000 ALTER TABLE `VersionInfo` DISABLE KEYS */;
INSERT INTO `VersionInfo` VALUES (1,'0000-00-00 00:00:00','InitialSetup'),(2,'0000-00-00 00:00:00','remove_tvrage_imdb_unique_constraint'),(3,'0000-00-00 00:00:00','remove_renamed_scene_mapping_columns'),(4,'0000-00-00 00:00:00','updated_history'),(5,'0000-00-00 00:00:00','added_eventtype_to_history'),(6,'0000-00-00 00:00:00','add_index_to_log_time'),(7,'0000-00-00 00:00:00','add_renameEpisodes_to_naming'),(8,'0000-00-00 00:00:00','remove_backlog'),(9,'0000-00-00 00:00:00','fix_rename_episodes'),(10,'0000-00-00 00:00:00','add_monitored'),(11,'0000-00-00 00:00:00','remove_ignored'),(12,'0000-00-00 00:00:00','remove_custom_start_date'),(13,'0000-00-00 00:00:00','add_air_date_utc'),(14,'0000-00-00 00:00:00','drop_air_date'),(15,'0000-00-00 00:00:00','add_air_date_as_string'),(16,'0000-00-00 00:00:00','updated_imported_history_item'),(17,'0000-00-00 00:00:00','reset_scene_names'),(18,'0000-00-00 00:00:00','remove_duplicates'),(19,'0000-00-00 00:00:00','restore_unique_constraints'),(20,'0000-00-00 00:00:00','add_year_and_seasons_to_series'),(21,'0000-00-00 00:00:00','drop_seasons_table'),(22,'0000-00-00 00:00:00','move_indexer_to_generic_provider'),(23,'0000-00-00 00:00:00','add_config_contract_to_indexers'),(24,'0000-00-00 00:00:00','drop_tvdb_episodeid'),(25,'0000-00-00 00:00:00','move_notification_to_generic_provider'),(26,'0000-00-00 00:00:00','add_config_contract_to_notifications'),(27,'0000-00-00 00:00:00','fix_omgwtfnzbs'),(28,'0000-00-00 00:00:00','add_blacklist_table'),(29,'0000-00-00 00:00:00','add_formats_to_naming_config'),(30,'0000-00-00 00:00:00','add_season_folder_format_to_naming_config'),(31,'0000-00-00 00:00:00','delete_old_naming_config_columns'),(32,'0000-00-00 00:00:00','set_default_release_group'),(33,'0000-00-00 00:00:00','add_api_key_to_pushover'),(34,'0000-00-00 00:00:00','remove_series_contraints'),(35,'0000-00-00 00:00:00','add_series_folder_format_to_naming_config'),(36,'0000-00-00 00:00:00','update_with_quality_converters'),(37,'0000-00-00 00:00:00','add_configurable_qualities'),(38,'0000-00-00 00:00:00','add_on_upgrade_to_notifications'),(39,'0000-00-00 00:00:00','add_metadata_tables'),(40,'0000-00-00 00:00:00','add_metadata_to_episodes_and_series'),(41,'0000-00-00 00:00:00','fix_xbmc_season_images_metadata'),(42,'0000-00-00 00:00:00','add_download_clients_table'),(43,'0000-00-00 00:00:00','convert_config_to_download_clients'),(44,'0000-00-00 00:00:00','fix_xbmc_episode_metadata'),(45,'0000-00-00 00:00:00','add_indexes'),(46,'0000-00-00 00:00:00','fix_nzb_su_url'),(47,'0000-00-00 00:00:00','add_temporary_blacklist_columns'),(48,'0000-00-00 00:00:00','add_title_to_scenemappings'),(49,'0000-00-00 00:00:00','fix_dognzb_url'),(50,'0000-00-00 00:00:00','add_hash_to_metadata_files'),(51,'0000-00-00 00:00:00','download_client_import'),(52,'0000-00-00 00:00:00','add_columns_for_anime'),(53,'0000-00-00 00:00:00','add_series_sorttitle'),(54,'0000-00-00 00:00:00','rename_profiles'),(55,'0000-00-00 00:00:00','drop_old_profile_columns'),(56,'0000-00-00 00:00:00','add_mediainfo_to_episodefile'),(57,'0000-00-00 00:00:00','convert_episode_file_path_to_relative'),(58,'0000-00-00 00:00:00','drop_episode_file_path'),(59,'0000-00-00 00:00:00','add_enable_options_to_indexers'),(60,'0000-00-00 00:00:00','remove_enable_from_indexers'),(61,'0000-00-00 00:00:00','clear_bad_scene_names'),(62,'0000-00-00 00:00:00','convert_quality_models'),(63,'0000-00-00 00:00:00','add_remotepathmappings'),(64,'0000-00-00 00:00:00','remove_method_from_logs'),(65,'0000-00-00 00:00:00','make_scene_numbering_nullable'),(66,'0000-00-00 00:00:00','add_tags'),(67,'0000-00-00 00:00:00','add_added_to_series'),(68,'0000-00-00 00:00:00','add_release_restrictions'),(69,'0000-00-00 00:00:00','quality_proper'),(70,'0000-00-00 00:00:00','delay_profile'),(71,'0000-00-00 00:00:00','unknown_quality_in_profile'),(72,'0000-00-00 00:00:00','history_downloadId'),(73,'0000-00-00 00:00:00','clear_ratings'),(74,'0000-00-00 00:00:00','disable_eztv'),(75,'0000-00-00 00:00:00','force_lib_update'),(76,'0000-00-00 00:00:00','add_users_table'),(77,'0000-00-00 00:00:00','add_add_options_to_series'),(78,'0000-00-00 00:00:00','add_commands_table'),(79,'0000-00-00 00:00:00','dedupe_tags'),(81,'0000-00-00 00:00:00','move_dot_prefix_to_transmission_category'),(82,'0000-00-00 00:00:00','add_fanzub_settings'),(83,'0000-00-00 00:00:00','additonal_blacklist_columns'),(84,'0000-00-00 00:00:00','update_quality_minmax_size'),(85,'0000-00-00 00:00:00','expand_transmission_urlbase'),(86,'0000-00-00 00:00:00','pushbullet_device_ids'),(87,'0000-00-00 00:00:00','remove_eztv'),(88,'0000-00-00 00:00:00','pushbullet_devices_channels_list'),(89,'0000-00-00 00:00:00','add_on_rename_to_notifcations'),(90,'0000-00-00 00:00:00','update_kickass_url'),(91,'0000-00-00 00:00:00','added_indexerstatus'),(92,'0000-00-00 00:00:00','add_unverifiedscenenumbering'),(93,'0000-00-00 00:00:00','naming_config_replace_illegal_characters'),(94,'0000-00-00 00:00:00','add_tvmazeid'),(95,'0000-00-00 00:00:00','add_additional_episodes_index'),(96,'0000-00-00 00:00:00','disable_kickass'),(98,'0000-00-00 00:00:00','remove_titans_of_tv'),(99,'0000-00-00 00:00:00','extra_and_subtitle_files'),(100,'0000-00-00 00:00:00','add_scene_season_number'),(101,'0000-00-00 00:00:00','add_ultrahd_quality_in_profiles'),(103,'0000-00-00 00:00:00','fix_metadata_file_extensions'),(104,'0000-00-00 00:00:00','add_moviefiles_table'),(105,'0000-00-00 00:00:00','fix_history_movieId'),(106,'0000-00-00 00:00:00','add_tmdb_stuff'),(107,'0000-00-00 00:00:00','fix_movie_files'),(108,'0000-00-00 00:00:00','update_schedule_intervale'),(109,'0000-00-00 00:00:00','add_movie_formats_to_naming_config'),(110,'0000-00-00 00:00:00','add_phyiscal_release'),(111,'0000-00-00 00:00:00','remove_bitmetv'),(112,'0000-00-00 00:00:00','remove_torrentleech'),(113,'0000-00-00 00:00:00','remove_broadcasthenet'),(114,'0000-00-00 00:00:00','remove_fanzub'),(115,'0000-00-00 00:00:00','update_movie_sorttitle'),(116,'0000-00-00 00:00:00','update_movie_sorttitle_again'),(117,'0000-00-00 00:00:00','update_movie_file'),(118,'0000-00-00 00:00:00','update_movie_slug'),(119,'0000-00-00 00:00:00','add_youtube_trailer_id'),(120,'0000-00-00 00:00:00','add_studio'),(121,'0000-00-00 00:00:00','update_filedate_config'),(122,'0000-00-00 00:00:00','add_movieid_to_blacklist'),(123,'0000-00-00 00:00:00','create_netimport_table'),(124,'0000-00-00 00:00:00','add_preferred_tags_to_profile'),(125,'0000-00-00 00:00:00','fix_imdb_unique'),(126,'0000-00-00 00:00:00','update_qualities_and_profiles'),(127,'0000-00-00 00:00:00','remove_wombles_kickass'),(128,'0000-00-00 00:00:00','remove_kickass'),(129,'0000-00-00 00:00:00','add_parsed_movie_info_to_pending_release'),(131,'0000-00-00 00:00:00','make_parsed_episode_info_nullable'),(132,'0000-00-00 00:00:00','rename_torrent_downloadstation'),(133,'0000-00-00 00:00:00','add_minimumavailability'),(134,'0000-00-00 00:00:00','add_remux_qualities_for_the_wankers'),(135,'0000-00-00 00:00:00','add_haspredbentry_to_movies'),(136,'0000-00-00 00:00:00','add_pathstate_to_movies'),(137,'0000-00-00 00:00:00','add_import_exclusions_table'),(138,'0000-00-00 00:00:00','add_physical_release_note'),(139,'0000-00-00 00:00:00','consolidate_indexer_baseurl'),(140,'0000-00-00 00:00:00','add_alternative_titles_table'),(141,'0000-00-00 00:00:00','fix_duplicate_alt_titles'),(142,'0000-00-00 00:00:00','movie_extras'),(143,'0000-00-00 00:00:00','clean_core_tv'),(144,'0000-00-00 00:00:00','add_cookies_to_indexer_status'),(145,'0000-00-00 00:00:00','banner_to_fanart'),(146,'0000-00-00 00:00:00','naming_config_colon_action'),(147,'0000-00-00 00:00:00','add_custom_formats'),(148,'0000-00-00 00:00:00','remove_extra_naming_config'),(149,'0000-00-00 00:00:00','convert_regex_required_tags'),(150,'0000-00-00 00:00:00','fix_format_tags_double_underscore');
/*!40000 ALTER TABLE `VersionInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlite_sequence`
--

DROP TABLE IF EXISTS `sqlite_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlite_sequence` (
  `name` blob,
  `seq` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlite_sequence`
--

LOCK TABLES `sqlite_sequence` WRITE;
/*!40000 ALTER TABLE `sqlite_sequence` DISABLE KEYS */;
INSERT INTO `sqlite_sequence` VALUES ('Config','1'),('Indexers','0'),('DownloadClients','0'),('DelayProfiles','1'),('Profiles','6'),('Tags','0'),('QualityDefinitions','26'),('Notifications','0'),('MovieFiles','0'),('ScheduledTasks','11'),('Movies','0'),('AlternativeTitles','0'),('Blacklist','0'),('History','0'),('NamingConfig','0'),('PendingReleases','0'),('Metadata','4'),('Commands','109');
/*!40000 ALTER TABLE `sqlite_sequence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-08 22:54:01
